    return a >= 3;} // Prevents main becoming empty.
