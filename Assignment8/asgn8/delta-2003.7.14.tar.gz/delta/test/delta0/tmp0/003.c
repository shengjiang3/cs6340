// We are trying to find the minimum version of this program that
// compiles but returns false.
#include <stdio.h>
