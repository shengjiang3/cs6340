int main(int argc, char **argv) {
    int a = 0;
    a++;
    return a >= 3;} // Prevents main becoming empty.
