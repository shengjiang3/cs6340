    int a = 0;
    a+=2;
    a++;
    return a >= 3;} // Prevents main becoming empty.
