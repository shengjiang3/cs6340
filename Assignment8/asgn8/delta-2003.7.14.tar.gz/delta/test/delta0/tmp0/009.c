// We are trying to find the minimum version of this program that
// compiles but returns false.
#include <stdio.h>
    a++;
    a--;
    a+=2;
    a++;
    a--;
    a++;
    return a >= 3;} // Prevents main becoming empty.
