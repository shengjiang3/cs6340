int main(int argc, char **argv) {
    a++;
    a--;
    a+=2;
    a++;
    return a >= 3;} // Prevents main becoming empty.
