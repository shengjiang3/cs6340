    a++;
    a--;
    a+=2;
    a++;
    a--;
    a++;
    return a >= 3;} // Prevents main becoming empty.
