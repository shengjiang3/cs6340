    int a = 0;
