    int a = 0;
    printf("Hello, World!\n");
